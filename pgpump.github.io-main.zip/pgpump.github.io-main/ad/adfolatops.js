document.write('<div id="floatads" style="width:100%;margin:auto; text-align:center;float:none;overflow:hidden; display:scroll;position:fixed; top:0;z-index:9999;opacity:0.01">');
document.write('<div style="text-align:center;display:block;max-width:729px;height:auto;overflow:hidden;margin:auto;">');

atOptions = {
    'key': 'fa36fa4c82dc8022fda12fbc52902556',
    'format': 'iframe',
    'height': 90,
    'width': 728,
    'params': {}
};
document.write('<scr' + 'ipt type="text/javascript" src="//stupidityblueberryblessing.com/fa36fa4c82dc8022fda12fbc52902556/invoke.js"></scr' + 'ipt>');

document.write('</div>');
document.write('</div>');
