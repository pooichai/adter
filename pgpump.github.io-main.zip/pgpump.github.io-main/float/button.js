document.write(`
<div id='floatads' style='width:100%;margin:auto; text-align:center;float:none;overflow:hidden; display:scroll;position:fixed; bottom:0;z-index:9999'>
  <div>
    <a id='close-floatads' onclick='document.getElementById("floatads").style.display = "none";' style='cursor:pointer;'>
      <img src='https://3.bp.blogspot.com/-ZZSacDHLWlM/VhvlKTMjbLI/AAAAAAAAF2M/UDzU4rrvcaI/s1600/btn_close.gif'/>
    </a>
  </div>
  <div style='text-align:center;display:block;max-width:728px;height:auto;overflow:hidden;margin:auto'>
    <script src="https://pgpump.github.io/float/folat.js" type="text/javascript"><\/script>
  </div>
</div>
`);
